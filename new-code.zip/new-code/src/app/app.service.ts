import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class AppService {

  private DO_POST = "http://192.168.33.45:7070/addEmployee";
  // private FETCH_DATA = "http://192.168.33.45:7070/getAllEmployee";
  private FETCH_DATA = "/assets/Data/employee.json";

  constructor(private httpClient: HttpClient) { }

  doPOST(data) {
    console.log("POST");
    return this.httpClient.post(this.DO_POST, data);
  }

  getPost() {
    return this.httpClient.get(this.FETCH_DATA);
  }

  getEmployee() {
    return this.httpClient.get(this.FETCH_DATA);

  }
}